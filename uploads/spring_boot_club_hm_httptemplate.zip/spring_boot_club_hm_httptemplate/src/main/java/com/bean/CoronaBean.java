package com.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CoronaBean {

	
	
	private String country;
	private String provinces[];
	

	




	public String[] getProvinces() {
		return provinces;
	}

	public void setProvinces(String[] provinces) {
		this.provinces = provinces;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

		
}
