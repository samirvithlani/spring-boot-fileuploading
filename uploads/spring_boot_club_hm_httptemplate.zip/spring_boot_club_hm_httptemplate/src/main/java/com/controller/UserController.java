package com.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bean.CoronaBean;
import com.bean.EmployeeBean;
import com.bean.Province;
import com.bean.UserBean;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class UserController {

	@Autowired
	RestTemplate restTemplate;

	@RequestMapping("/getallusers")
	public void getAllUsers() {

		final String url = "http://localhost:8080/user/viewuser";
		String result = restTemplate.getForObject(url, String.class);
		System.out.println(result);

		ResponseEntity<UserBean[]> responseEntity = restTemplate.getForEntity(url, UserBean[].class);
		List<UserBean> users = Arrays.asList(responseEntity.getBody());

		for (UserBean user : users) {

			System.out.println(user.getuId());
			System.out.println(user.getuName());

		}

	}

	@RequestMapping(value = "/corona")
	public void getCoronaData() {

		/*
		 * System.out.println("method called..."); HttpHeaders headers = new
		 * HttpHeaders();
		 * 
		 * headers.set("x-rapidapi-host", "covid-19-data.p.rapidapi.com");
		 * headers.set("x-rapidapi-key",
		 * "b5ec0b6113msh9196fbc1a87b19cp15a354jsn5548e4945b01");
		 * 
		 * final HttpEntity<String> entity = new HttpEntity<String>(headers);
		 * 
		 * String url = "https://covid-19-data.p.rapidapi.com/report/country/name";
		 * Map<String, String> params = new HashMap<>();
		 * 
		 * params.put("name", "India"); params.put("date", "2020-04-01");
		 * 
		 * UriComponentsBuilder builder =
		 * UriComponentsBuilder.fromUriString(url).queryParam("name", "India")
		 * .queryParam("date", "2020-04-01");
		 * 
		 * System.out.println("**");
		 * 
		 * ResponseEntity<String> res =
		 * restTemplate.exchange(builder.buildAndExpand(params).toUri(), HttpMethod.GET,
		 * entity, String.class);
		 * 
		 * 
		 * System.out.println(res.getBody());
		 * 
		 * 
		 * //String json = res.getBody().toString(); //System.out.println(json);
		 */

		String json = "[{\"country\":\"India\",\"provinces\":[{\"province\":\"India\",\"confirmed\":1998,\"recovered\":148,\"deaths\":58,\"active\":1792}],\"latitude\":20.593684,\"longitude\":78.96288,\"date\":\"2020-04-01\"}]";

		ObjectMapper mapper = new ObjectMapper();
		try {
			CoronaBean coronaBean[] = mapper.readValue(json, CoronaBean[].class);

			for (CoronaBean c : coronaBean) {

				System.out.println(c.getCountry());
				for (String p : c.getProvinces()) {

					System.out.println(p);
				}

			}

		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("--");
	}

	@RequestMapping(value = "/dummy")
	public void dummy() {

		Map<String, String> params = new HashMap<>();
		params.put("id", "3");
		final String url = "http://localhost:8082/user/viewuser/{uid}";
		HttpHeaders headers = new HttpHeaders();
		headers.set("", "");

		params.put("uid", "1");

		UserBean userBean = restTemplate.getForObject(url, UserBean.class, params);
		System.out.println(userBean.getuName());
		System.out.println(userBean.getuEmail());

		// List<EmployeeBean> rates = rateResponse.getBody();

	}

	@RequestMapping(value = "/getuserbyid")
	public void getDatabyid() {

		final String url = "http://localhost:8082/user/viewuser/{uid}";
		HttpHeaders headers = new HttpHeaders();
		final HttpEntity<String> entity = new HttpEntity(headers);

		Map<String, String> params = new HashMap<String, String>();

		params.put("uid", "1");

		UserBean userBean = restTemplate.getForObject(url, UserBean.class, params);
		System.out.println(userBean.getuName());
		System.out.println(userBean.getuEmail());

	}
}
